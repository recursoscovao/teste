(function () {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  let state = { index: 0, points: 0, correct: 0, attempts: 0 };

  function questions() {
    if (Array.isArray(dados.niveis)) {
      return dados.niveis.flatMap(n => n.perguntas || []);
    }
    return dados.perguntas || [];
  }

  function init() {
    document.title = dados.titulo || 'Jogo';
    $('#jogo-titulo').textContent = dados.titulo || '';
    $('#jogo-subtitulo').textContent = dados.subtitulo || '';

    const content = $('#game-content');
    if (!content) return;

    if (dados.tipo === 'escrever-frase') renderDictation(content);
    else if (dados.tipo === 'memoria') renderMemory(content);
    else if (dados.tipo === 'ordenar') renderOrder(content);
    else renderQuiz(content);
  }

  function renderQuiz(content) {
    const q = questions()[state.index];
    if (!q) return finish(content);

    content.innerHTML = `
      <section class="game-card">
        <div class="question">${q.pergunta || 'Escolhe a resposta'}</div>
        ${q.imagem ? `<img class="question-image" src="${q.imagem}" alt="">` : ''}
        <div class="answers">
          ${(q.opcoes || []).map((o, i) => `
            <button class="game-option" data-index="${i}">
              ${q.opcaoImagens?.[i] ? `<img src="${q.opcaoImagens[i]}" alt="">` : ''}
              <span>${o}</span>
            </button>
          `).join('')}
        </div>
        <div class="feedback" aria-live="polite"></div>
      </section>`;

    content.querySelectorAll('.game-option').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.index);
        const ok = q.respostaIndex === i || q.resposta === q.opcoes?.[i];

        content.querySelectorAll('.game-option').forEach(b => b.disabled = true);
        $('.feedback', content).textContent = ok ? 'Muito bem!' : 'Vamos continuar!';
        if (ok) {
          state.correct++;
          state.points += q.pontos || 10;
        }
        state.attempts++;

        setTimeout(() => {
          state.index++;
          init();
        }, 650);
      });
    });
  }

  function speak(text, rate) {
    if (!('speechSynthesis' in window)) return false;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = dados.idioma || 'pt-PT';
    u.rate = rate || 0.88;
    u.pitch = 1;
    speechSynthesis.speak(u);
    return true;
  }

  function normalise(s) {
    return s.trim().replace(/\s+/g, ' ').replace(/[“”"]/g, '"').toLocaleLowerCase('pt-PT');
  }

  function renderDictation(content) {
    const q = questions()[state.index];
    if (!q) return finish(content);

    content.innerHTML = `
      <section class="game-card">
        <div class="question">${q.instrucao || 'Ouve a frase e escreve-a.'}</div>
        ${q.imagem ? `<img class="question-image" src="${q.imagem}" alt="">` : ''}
        <div class="audio-row">
          <button class="primary-btn" id="ouvir">🔊 Ouvir</button>
          <button class="primary-btn" id="repetir">↻ Repetir</button>
          ${q.lento ? `<button class="primary-btn" id="lento">🐢 Ouvir devagar</button>` : ''}
        </div>
        <input class="text-answer" id="resposta" autocomplete="off" autocapitalize="sentences"
               spellcheck="true" placeholder="Escreve aqui a frase...">
        <button class="primary-btn" id="verificar">Verificar</button>
        <div class="hint">${q.dica || 'Começa por ouvir com atenção.'}</div>
        <div class="feedback" aria-live="polite"></div>
      </section>`;

    const play = rate => {
      if (!speak(q.texto, rate)) {
        $('.feedback', content).textContent = 'O teu dispositivo não disponibiliza leitura de voz.';
      }
    };

    $('#ouvir', content).onclick = () => play(q.velocidade || 0.88);
    $('#repetir', content).onclick = () => play(q.velocidade || 0.88);
    if ($('#lento', content)) $('#lento', content).onclick = () => play(q.velocidadeLenta || 0.65);

    $('#resposta', content).focus();
    $('#resposta', content).addEventListener('keydown', e => {
      if (e.key === 'Enter') $('#verificar', content).click();
    });

    $('#verificar', content).onclick = () => {
      const answer = $('#resposta', content).value;
      const ok = normalise(answer) === normalise(q.texto);
      const feedback = $('.feedback', content);

      state.attempts++;
      if (ok) {
        state.correct++;
        state.points += q.pontos || 10;
        feedback.textContent = 'Muito bem! A frase está correta.';
        $('#verificar', content).disabled = true;
        setTimeout(() => { state.index++; init(); }, 900);
      } else {
        feedback.textContent = q.ajuda || 'Ainda não. Ouve novamente e tenta outra vez.';
        $('#resposta', content).focus();
      }
    };
  }

  function renderMemory(content) {
    const items = dados.cartas || [];
    const cards = [...items, ...items].sort(() => Math.random() - 0.5);
    let first = null, busy = false, found = 0;

    content.innerHTML = `
      <section class="game-card">
        <div class="question">${dados.instrucao || 'Encontra os pares.'}</div>
        <div class="answers">
          ${cards.map((x, i) => `
            <button class="game-option" data-i="${i}">
              <span>?</span>
              <img src="${x.imagem || x}" alt="" style="display:none">
            </button>`).join('')}
        </div>
        <div class="feedback"></div>
      </section>`;

    const buttons = [...content.querySelectorAll('.game-option')];

    buttons.forEach((b, i) => {
      b.onclick = () => {
        if (busy || b.dataset.open === '1') return;
        b.dataset.open = '1';
        b.innerHTML = `<img src="${cards[i].imagem || cards[i]}" alt="">`;

        if (first === null) { first = i; return; }
        busy = true;
        const a = cards[first].id || cards[first].imagem || cards[first];
        const c = cards[i].id || cards[i].imagem || cards[i];

        setTimeout(() => {
          if (a === c) {
            found += 2;
            state.points += 10;
          } else {
            buttons[first].dataset.open = '0';
            buttons[first].innerHTML = '<span>?</span>';
            b.dataset.open = '0';
            b.innerHTML = '<span>?</span>';
          }
          first = null;
          busy = false;
          if (found === cards.length) finish(content);
        }, 450);
      };
    });
  }

  function renderOrder(content) {
    const q = questions()[state.index];
    if (!q) return finish(content);

    const items = [...(q.itens || [])].sort(() => Math.random() - 0.5);
    content.innerHTML = `
      <section class="game-card">
        <div class="question">${q.pergunta || 'Coloca pela ordem correta.'}</div>
        <div class="answers" id="ordem">
          ${items.map((x, i) => `
            <button class="game-option" data-id="${x.id ?? x.valor ?? i}">
              ${x.imagem ? `<img src="${x.imagem}" alt="">` : ''}
              <span>${x.nome ?? x.valor ?? x}</span>
            </button>`).join('')}
        </div>
        <button class="primary-btn" id="confirmar">Confirmar</button>
        <div class="feedback"></div>
      </section>`;

    const box = $('#ordem', content);
    box.querySelectorAll('.game-option').forEach(btn => {
      btn.onclick = () => box.appendChild(btn);
    });

    $('#confirmar', content).onclick = () => {
      const got = [...box.querySelectorAll('.game-option')].map(x => x.dataset.id);
      const expected = (q.ordem || []).map(String);
      const ok = got.map(String).join('|') === expected.join('|');
      $('.feedback', content).textContent = ok ? 'Muito bem!' : 'A ordem ainda não está certa.';
      if (ok) {
        state.points += q.pontos || 10;
        state.correct++;
        $('#confirmar', content).disabled = true;
        setTimeout(() => { state.index++; init(); }, 800);
      }
    };
  }

  function finish(content) {
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    content.innerHTML = `
      <section class="game-card">
        <h2 style="margin:0;color:#5EA2E6;font-size:clamp(1.6rem,4vw,2.4rem)">Parabéns!</h2>
        <p>Terminaste este desafio.</p>
        <div class="score">${state.points} pontos</div>
        <p>Acertos: ${state.correct}</p>
        <button class="primary-btn" onclick="location.reload()">Jogar novamente</button>
      </section>`;
  }

  window.addEventListener('resize', () => {
    document.documentElement.style.setProperty('--vw', innerWidth + 'px');
    document.documentElement.style.setProperty('--vh', innerHeight + 'px');
  }, { passive: true });

  document.addEventListener('DOMContentLoaded', init);
})();
