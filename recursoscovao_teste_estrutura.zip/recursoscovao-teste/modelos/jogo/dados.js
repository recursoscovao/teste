const dados = { titulo:"Nome do jogo", subtitulo:"Subtítulo", tipo:"quiz", perguntas:[] };
