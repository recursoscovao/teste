const DADOS_JOGO={
  "nome": "Doméstico ou Selvagem",
  "descricao": "Escolhe o grupo certo.",
  "area": "em",
  "primary": "#994D4D",
  "bg": "#EAE2E5",
  "back": "voltar_cs.png",
  "dados": [
    {
      "nome": "cão",
      "img": "../../../../img/animaisdomesticos/cao.png",
      "resposta": "DOMÉSTICO",
      "opcoes": [
        "SELVAGEM",
        "AVE"
      ]
    },
    {
      "nome": "gato",
      "img": "../../../../img/animaisdomesticos/gato1.png",
      "resposta": "DOMÉSTICO",
      "opcoes": [
        "SELVAGEM",
        "PEIXE"
      ]
    },
    {
      "nome": "leão",
      "img": "../../../../img/animaisselvagens/leao.png",
      "resposta": "SELVAGEM",
      "opcoes": [
        "DOMÉSTICO",
        "AVE"
      ]
    },
    {
      "nome": "tigre",
      "img": "../../../../img/animaisselvagens/tigre.png",
      "resposta": "SELVAGEM",
      "opcoes": [
        "DOMÉSTICO",
        "INSETO"
      ]
    },
    {
      "nome": "elefante",
      "img": "../../../../img/animaisselvagens/elefante.png",
      "resposta": "SELVAGEM",
      "opcoes": [
        "DOMÉSTICO",
        "AVE"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
