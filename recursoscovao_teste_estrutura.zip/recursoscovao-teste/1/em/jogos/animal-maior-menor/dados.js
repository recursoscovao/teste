const DADOS_JOGO={
  "nome": "Animais: Maior ou Menor",
  "descricao": "Escolhe o animal maior.",
  "area": "em",
  "primary": "#994D4D",
  "bg": "#EAE2E5",
  "back": "voltar_cs.png",
  "dados": [
    {
      "nome": "elefante",
      "img": "../../../../img/animaisselvagens/elefante.png",
      "resposta": "ELEFANTE",
      "opcoes": [
        "RATO",
        "COELHO"
      ]
    },
    {
      "nome": "baleia",
      "img": "../../../../img/animaisselvagens/baleia.png",
      "resposta": "BALEIA",
      "opcoes": [
        "GATO",
        "RATO"
      ]
    },
    {
      "nome": "girafa",
      "img": "../../../../img/animaisselvagens/girafa.png",
      "resposta": "GIRAFA",
      "opcoes": [
        "COELHO",
        "RATO"
      ]
    },
    {
      "nome": "tigre",
      "img": "../../../../img/animaisselvagens/tigre.png",
      "resposta": "TIGRE",
      "opcoes": [
        "RATO",
        "BORBOLETA"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
