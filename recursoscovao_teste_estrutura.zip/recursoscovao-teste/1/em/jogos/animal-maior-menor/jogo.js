
const C=DADOS_JOGO,$=s=>document.querySelector(s);
document.documentElement.style.setProperty('--p',C.primary);document.documentElement.style.setProperty('--bg',C.bg);
$('#title').textContent=C.nome;$('#back').src='../../../icons/'+C.back;$('#back').onclick=()=>history.back();
C.menu.forEach(x=>{const a=document.createElement('a');a.href=x[1];a.innerHTML='<img src="../../../icons/'+x[2]+'" alt=""><span>'+x[0]+'</span>';$('#menu').appendChild(a)});
$('#mb').onclick=e=>{e.stopPropagation();$('#menu').style.display=$('#menu').style.display==='flex'?'none':'flex'};window.addEventListener('click',()=>$('#menu').style.display='none');
let score=0,round=0,open=[],lock=false,matched=0,running=true;
function shuffle(a){return a.sort(()=>Math.random()-.5)}function msg(t){$('.feedback').textContent=t}function pt(){score++;$('#points').textContent=score}
function shell(){ $('#game').innerHTML='<div class="q"><div class="ins" id="ins"></div><div id="area"></div><div class="feedback" aria-live="polite"></div></div>';$('#foot').innerHTML='<button class="btn secondary" id="restart" type="button">↻ Recomeçar</button><div class="points">Pontos: <span id="points">0</span></div>';$('#restart').onclick=()=>{score=0;round=0;open=[];matched=0;lock=false;running=true;$('#points').textContent=0;render()};render()}
function end(){running=false;msg('Terminaste! '+score+' pontos ⭐');$('#ins').textContent='Muito bem! Recomeça quando quiseres.'}

function render(){if(round>=10){end();return}const d=C.dados[round%C.dados.length];$('#ins').textContent='Ronda '+(round+1)+' de 10 — '+C.descricao;$('#area').innerHTML='<div class="visual"><img src="'+d.img+'" alt="'+d.nome+'"></div><div class="choices" id="choices"></div>';shuffle([d.resposta,...d.opcoes]).slice(0,3).forEach(v=>{const b=document.createElement('button');b.className='choice';b.type='button';b.textContent=v;b.onclick=()=>answer(b,v,d.resposta);$('#choices').appendChild(b)})}
function answer(b,v,c){[...$('#choices').children].forEach(x=>x.disabled=true);if(v===c){b.classList.add('correct');pt();msg('Muito bem! ⭐')}else{b.classList.add('wrong');msg('Quase! A resposta é '+c+'.')}round++;setTimeout(render,650)}

shell();
