const DADOS_JOGO={
  "nome": "Memória dos Animais",
  "descricao": "Encontra os pares de animais.",
  "area": "em",
  "primary": "#994D4D",
  "bg": "#EAE2E5",
  "back": "voltar_cs.png",
  "dados": [
    {
      "valor": "🐶"
    },
    {
      "valor": "🐱"
    },
    {
      "valor": "🐰"
    },
    {
      "valor": "🐮"
    },
    {
      "valor": "🐷"
    },
    {
      "valor": "🐴"
    },
    {
      "valor": "🦁"
    },
    {
      "valor": "🐯"
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
