
const C=DADOS_JOGO,$=s=>document.querySelector(s);
document.documentElement.style.setProperty('--p',C.primary);document.documentElement.style.setProperty('--bg',C.bg);
$('#title').textContent=C.nome;$('#back').src='../../../icons/'+C.back;$('#back').onclick=()=>history.back();
C.menu.forEach(x=>{const a=document.createElement('a');a.href=x[1];a.innerHTML='<img src="../../../icons/'+x[2]+'" alt=""><span>'+x[0]+'</span>';$('#menu').appendChild(a)});
$('#mb').onclick=e=>{e.stopPropagation();$('#menu').style.display=$('#menu').style.display==='flex'?'none':'flex'};window.addEventListener('click',()=>$('#menu').style.display='none');
let score=0,round=0,open=[],lock=false,matched=0,running=true;
function shuffle(a){return a.sort(()=>Math.random()-.5)}function msg(t){$('.feedback').textContent=t}function pt(){score++;$('#points').textContent=score}
function shell(){ $('#game').innerHTML='<div class="q"><div class="ins" id="ins"></div><div id="area"></div><div class="feedback" aria-live="polite"></div></div>';$('#foot').innerHTML='<button class="btn secondary" id="restart" type="button">↻ Recomeçar</button><div class="points">Pontos: <span id="points">0</span></div>';$('#restart').onclick=()=>{score=0;round=0;open=[];matched=0;lock=false;running=true;$('#points').textContent=0;render()};render()}
function end(){running=false;msg('Terminaste! '+score+' pontos ⭐');$('#ins').textContent='Muito bem! Recomeça quando quiseres.'}

function render(){open=[];matched=0;lock=false;$('#ins').textContent=C.descricao;const vals=C.dados.map(x=>x.valor),cards=shuffle([...vals,...vals]),a=$('#area');a.innerHTML='<div class="memory" id="memory"></div>';cards.forEach((v,i)=>{const b=document.createElement('button');b.type='button';b.textContent='?';b.onclick=()=>flip(b,i,cards);$('#memory').appendChild(b)})}
function flip(b,i,c){if(lock||!running||b.classList.contains('done')||open.some(x=>x.i===i))return;b.classList.add('open');b.textContent=c[i];open.push({i,b});if(open.length===2){lock=true;if(c[open[0].i]===c[open[1].i]){open.forEach(x=>{x.b.classList.add('done');x.b.disabled=true});matched++;pt();msg('Par encontrado! ⭐');open=[];lock=false;if(matched===c.length/2)end()}else{msg('Tenta outra vez.');setTimeout(()=>{open.forEach(x=>{x.b.classList.remove('open');x.b.textContent='?'});open=[];lock=false},650)}}}

shell();
