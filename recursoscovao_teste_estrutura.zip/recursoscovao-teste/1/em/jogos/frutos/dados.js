const DADOS_JOGO={
  "nome": "Que Fruto é Este?",
  "descricao": "Escolhe o nome do fruto.",
  "area": "em",
  "primary": "#994D4D",
  "bg": "#EAE2E5",
  "back": "voltar_cs.png",
  "dados": [
    {
      "nome": "banana",
      "img": "../../../../img/frutos/banana.png",
      "resposta": "BANANA",
      "opcoes": [
        "MAÇÃ",
        "PERA"
      ]
    },
    {
      "nome": "maca",
      "img": "../../../../img/frutos/maca.png",
      "resposta": "MAÇÃ",
      "opcoes": [
        "BANANA",
        "KIWI"
      ]
    },
    {
      "nome": "pera",
      "img": "../../../../img/frutos/pera.png",
      "resposta": "PERA",
      "opcoes": [
        "UVA",
        "MORANGO"
      ]
    },
    {
      "nome": "morango",
      "img": "../../../../img/frutos/morango.png",
      "resposta": "MORANGO",
      "opcoes": [
        "CEREJA",
        "BANANA"
      ]
    },
    {
      "nome": "laranja",
      "img": "../../../../img/frutos/laranja.png",
      "resposta": "LARANJA",
      "opcoes": [
        "LIMÃO",
        "MELÃO"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
