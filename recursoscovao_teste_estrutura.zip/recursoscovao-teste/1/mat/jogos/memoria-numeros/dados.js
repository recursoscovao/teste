const DADOS_JOGO={
  "nome": "Memória dos Números",
  "descricao": "Encontra os pares de números iguais.",
  "area": "mat",
  "primary": "#45CFA8",
  "bg": "#E8F9F4",
  "back": "voltar_vr.png",
  "dados": [
    {
      "valor": "1"
    },
    {
      "valor": "2"
    },
    {
      "valor": "3"
    },
    {
      "valor": "4"
    },
    {
      "valor": "5"
    },
    {
      "valor": "6"
    },
    {
      "valor": "7"
    },
    {
      "valor": "8"
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
