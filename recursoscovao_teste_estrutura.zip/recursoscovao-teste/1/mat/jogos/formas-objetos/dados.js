const DADOS_JOGO={
  "nome": "Formas e Objetos",
  "descricao": "Escolhe a forma parecida com o objeto.",
  "area": "mat",
  "primary": "#45CFA8",
  "bg": "#E8F9F4",
  "back": "voltar_vr.png",
  "dados": [
    {
      "nome": "bola",
      "img": "../../../../img/objetos/bola.png",
      "resposta": "CÍRCULO",
      "opcoes": [
        "QUADRADO",
        "TRIÂNGULO"
      ]
    },
    {
      "nome": "regua",
      "img": "../../../../img/objetos/regua.png",
      "resposta": "RETÂNGULO",
      "opcoes": [
        "CÍRCULO",
        "TRIÂNGULO"
      ]
    },
    {
      "nome": "folha",
      "img": "../../../../img/objetos/folha.png",
      "resposta": "OVAL",
      "opcoes": [
        "TRIÂNGULO",
        "QUADRADO"
      ]
    },
    {
      "nome": "livro",
      "img": "../../../../img/objetos/livro.png",
      "resposta": "RETÂNGULO",
      "opcoes": [
        "CÍRCULO",
        "OVAL"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
