const DADOS_JOGO={
  "nome": "Somas até 10",
  "descricao": "Resolve pequenas somas.",
  "area": "mat",
  "primary": "#45CFA8",
  "bg": "#E8F9F4",
  "back": "voltar_vr.png",
  "dados": [
    {
      "pergunta": "2 + 3 = ?",
      "resposta": "5",
      "opcoes": [
        "4",
        "6"
      ]
    },
    {
      "pergunta": "1 + 4 = ?",
      "resposta": "5",
      "opcoes": [
        "3",
        "6"
      ]
    },
    {
      "pergunta": "3 + 3 = ?",
      "resposta": "6",
      "opcoes": [
        "5",
        "7"
      ]
    },
    {
      "pergunta": "5 + 2 = ?",
      "resposta": "7",
      "opcoes": [
        "6",
        "8"
      ]
    },
    {
      "pergunta": "4 + 4 = ?",
      "resposta": "8",
      "opcoes": [
        "7",
        "9"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
