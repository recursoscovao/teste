const DADOS_JOGO={
  "nome": "Completa a Sequência",
  "descricao": "Escolhe o número que falta.",
  "area": "mat",
  "primary": "#45CFA8",
  "bg": "#E8F9F4",
  "back": "voltar_vr.png",
  "dados": [
    {
      "pergunta": "1, 2, ?, 4",
      "resposta": "3",
      "opcoes": [
        "5",
        "6"
      ]
    },
    {
      "pergunta": "2, 3, ?, 5",
      "resposta": "4",
      "opcoes": [
        "6",
        "1"
      ]
    },
    {
      "pergunta": "5, ?, 7, 8",
      "resposta": "6",
      "opcoes": [
        "4",
        "9"
      ]
    },
    {
      "pergunta": "7, 8, ?, 10",
      "resposta": "9",
      "opcoes": [
        "6",
        "11"
      ]
    },
    {
      "pergunta": "3, 4, 5, ?",
      "resposta": "6",
      "opcoes": [
        "7",
        "2"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
