const DADOS_JOGO={
  "nome": "Conta os Objetos",
  "descricao": "Conta e escolhe o número certo.",
  "area": "mat",
  "primary": "#45CFA8",
  "bg": "#E8F9F4",
  "back": "voltar_vr.png",
  "dados": [
    {
      "pergunta": "🍎 🍎 🍎",
      "resposta": "3",
      "opcoes": [
        "2",
        "4"
      ]
    },
    {
      "pergunta": "⚽ ⚽ ⚽ ⚽",
      "resposta": "4",
      "opcoes": [
        "3",
        "5"
      ]
    },
    {
      "pergunta": "🍌 🍌 🍌 🍌 🍌",
      "resposta": "5",
      "opcoes": [
        "4",
        "6"
      ]
    },
    {
      "pergunta": "🐶 🐶",
      "resposta": "2",
      "opcoes": [
        "1",
        "3"
      ]
    },
    {
      "pergunta": "⭐ ⭐ ⭐ ⭐ ⭐ ⭐",
      "resposta": "6",
      "opcoes": [
        "5",
        "7"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
