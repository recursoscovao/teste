const DADOS_JOGO={
  "nome": "Imagem e Palavra",
  "descricao": "Escolhe a palavra certa.",
  "area": "pt",
  "primary": "#5EA2E6",
  "bg": "#EAF4FE",
  "back": "voltar_az.png",
  "dados": [
    {
      "nome": "bola",
      "img": "../../../../img/objetos/bola.png",
      "resposta": "BOLA",
      "opcoes": [
        "BALA",
        "BOTA"
      ]
    },
    {
      "nome": "livro",
      "img": "../../../../img/objetos/livro.png",
      "resposta": "LIVRO",
      "opcoes": [
        "LATA",
        "LAGO"
      ]
    },
    {
      "nome": "lapis",
      "img": "../../../../img/objetos/lapis.png",
      "resposta": "LÁPIS",
      "opcoes": [
        "LATA",
        "LAGO"
      ]
    },
    {
      "nome": "gato",
      "img": "../../../../img/animaisdomesticos/gato.png",
      "resposta": "GATO",
      "opcoes": [
        "GALO",
        "PATO"
      ]
    },
    {
      "nome": "pera",
      "img": "../../../../img/frutos/pera.png",
      "resposta": "PERA",
      "opcoes": [
        "PIPA",
        "PENA"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
