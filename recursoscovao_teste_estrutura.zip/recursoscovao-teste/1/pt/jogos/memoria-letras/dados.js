const DADOS_JOGO={
  "nome": "Memória das Letras",
  "descricao": "Encontra os pares de letras iguais.",
  "area": "pt",
  "primary": "#5EA2E6",
  "bg": "#EAF4FE",
  "back": "voltar_az.png",
  "dados": [
    {
      "valor": "A"
    },
    {
      "valor": "B"
    },
    {
      "valor": "C"
    },
    {
      "valor": "D"
    },
    {
      "valor": "E"
    },
    {
      "valor": "F"
    },
    {
      "valor": "G"
    },
    {
      "valor": "H"
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
