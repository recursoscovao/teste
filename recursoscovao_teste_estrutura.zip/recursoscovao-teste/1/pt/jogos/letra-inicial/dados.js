const DADOS_JOGO={
  "nome": "Primeira Letra",
  "descricao": "Escolhe a primeira letra do nome da imagem.",
  "area": "pt",
  "primary": "#5EA2E6",
  "bg": "#EAF4FE",
  "back": "voltar_az.png",
  "dados": [
    {
      "nome": "gato",
      "img": "../../../../img/animaisdomesticos/gato1.png",
      "resposta": "G",
      "opcoes": [
        "P",
        "C"
      ]
    },
    {
      "nome": "pato",
      "img": "../../../../img/animaisdomesticos/pato.png",
      "resposta": "P",
      "opcoes": [
        "B",
        "G"
      ]
    },
    {
      "nome": "vaca",
      "img": "../../../../img/animaisdomesticos/vaca.png",
      "resposta": "V",
      "opcoes": [
        "F",
        "C"
      ]
    },
    {
      "nome": "coelho",
      "img": "../../../../img/animaisdomesticos/coelho.png",
      "resposta": "C",
      "opcoes": [
        "G",
        "O"
      ]
    },
    {
      "nome": "banana",
      "img": "../../../../img/frutos/banana.png",
      "resposta": "B",
      "opcoes": [
        "M",
        "P"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
