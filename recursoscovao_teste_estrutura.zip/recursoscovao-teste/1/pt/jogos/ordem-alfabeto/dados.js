const DADOS_JOGO={
  "nome": "Ordem do Alfabeto",
  "descricao": "Qual é a letra seguinte?",
  "area": "pt",
  "primary": "#5EA2E6",
  "bg": "#EAF4FE",
  "back": "voltar_az.png",
  "dados": [
    {
      "pergunta": "A → ?",
      "resposta": "B",
      "opcoes": [
        "C",
        "D"
      ]
    },
    {
      "pergunta": "B → ?",
      "resposta": "C",
      "opcoes": [
        "A",
        "D"
      ]
    },
    {
      "pergunta": "C → ?",
      "resposta": "D",
      "opcoes": [
        "E",
        "B"
      ]
    },
    {
      "pergunta": "D → ?",
      "resposta": "E",
      "opcoes": [
        "C",
        "F"
      ]
    },
    {
      "pergunta": "E → ?",
      "resposta": "F",
      "opcoes": [
        "G",
        "D"
      ]
    }
  ],
  "menu": [
    [
      "Início",
      "../../../index.html",
      "home.png"
    ],
    [
      "Pré-Escolar",
      "../../../pre/index.html",
      "iconpre.png"
    ],
    [
      "1º Ano",
      "../../../1/index.html",
      "icon1.png"
    ],
    [
      "2º Ano",
      "../../../2/index.html",
      "icon2.png"
    ],
    [
      "3º Ano",
      "../../../3/index.html",
      "icon3.png"
    ],
    [
      "4º Ano",
      "../../../4/index.html",
      "icon4.png"
    ]
  ]
};
