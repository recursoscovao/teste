const dados = {
  titulo: "Ouvir e escrever",
  subtitulo: "Ouve a frase e escreve-a",
  tipo: "escrever-frase",
  idioma: "pt-PT",

  niveis: [
    {
      nome: "Nível 1",
      perguntas: [
        {
          texto: "O gato corre.",
          pontos: 10,
          dica: "Ouve novamente se precisares."
        },
        {
          texto: "A Ana salta.",
          pontos: 10,
          dica: "Presta atenção às palavras."
        },
        {
          texto: "O cão dorme.",
          pontos: 10,
          dica: "Não te esqueças do ponto final."
        },
        {
          texto: "A Rita lê um livro.",
          pontos: 10,
          lento: true
        }
      ]
    }
  ]
};
